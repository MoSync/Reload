var config = module.exports;

config["WebUI RPC"] = {
    environment: "node",
    tests: [
        "**/*-test.js"
    ]
};

