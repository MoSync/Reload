define([
   'underscore',
   'backbone'
], function(_, Backbone){
    var FeedbackModel = Backbone.Model.extend({
    });
    // Return the model for the module
    return FeedbackModel;
});

