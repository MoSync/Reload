define([
   'underscore',
   'backbone'
], function(_, Backbone){
    var DebugModel = Backbone.Model.extend({
    });

    return DebugModel;
});
