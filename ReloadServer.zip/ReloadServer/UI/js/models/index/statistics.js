define([
   'underscore',
   'backbone'
], function(_, Backbone){
    var StatisticsModel = Backbone.Model.extend({
    });
    // Return the model for the module
    return StatisticsModel;
});
