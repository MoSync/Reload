define([
   'underscore',
   'backbone'
], function(_, Backbone){
    var SidebarReloadButtonModel = Backbone.Model.extend({
    });

    return SidebarReloadButtonModel;
});
