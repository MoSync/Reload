define([
   'underscore',
   'backbone'
], function(_, Backbone){
    var ContentNavModel = Backbone.Model.extend({
    });

    return ContentNavModel;
});

