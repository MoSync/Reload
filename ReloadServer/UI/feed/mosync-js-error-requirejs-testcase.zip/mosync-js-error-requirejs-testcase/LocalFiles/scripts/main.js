require.config({
    shim: {
    },

    paths: {
        jquery: 'vendor/jquery.min'
    }
});

require(['app'], function(app) {

    document.addEventListener( "deviceready", function() {
            // use app here
            mosync.rlog('inside requirejs logic');
            $('#screen').append($('<div>').append('append from main.js'));
            mosync.rlog(app);

            function alerterr()
            {
                alert("just before alert(nonexistingvar)");
                mosync.rlog("alert(nonexistingvar) coming up:");
                mosync.rlog(nonexistingvar);
                mosync.rlog("this is not shown in logoutput")
            }

            function rlogerr()
            {
                mosync.rlog("mosync.rlog(nonexistingvar) coming up:");
                mosync.rlog(nonexistingvar);
                mosync.rlog("this is not shown in logoutput")
            }

            function consolelogerr()
            {
                mosync.rlog("console.log(nonexistingvar) coming up:");
                console.log("console.log(nonexistingvar) coming up:");
                console.log(nonexistingvar);
                mosync.rlog("this is not shown in logoutput")
                console.log("this is not shown in logoutput")
            }
            function nonexistingfuncerr()
            {
                mosync.rlog("nonexistingfunc() coming up:");
                nonexistingfunc()
                mosync.rlog("this is not shown in logoutput")
            }

            alert("just before logging");
            mosync.rlog("mosync.rlog() test");

            // Uncomment the kind of error to try
            //alerterr();
            //rlogerr();
            //consolelogerr();
            nonexistingfuncerr();

        },
        true);
});
