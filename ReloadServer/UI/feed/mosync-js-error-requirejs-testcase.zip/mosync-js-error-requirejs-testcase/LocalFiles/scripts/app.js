define(['jquery'], function($) {
    $('#screen').append($('<div>').append('append from app.js'));
    return 'Hello from Yeoman!';
});
